class Farmer (
    override val username: String,
    override val password: String,
    override val name: String,
    override val lastName: String,
    override val phoneNumber: String,
    override val email: String,
    override val address: String,
    ) : User(
    username = username,
    password = password,
    name = name,
    lastName = lastName,
    phoneNumber = phoneNumber,
    email = email,
    address = address
)