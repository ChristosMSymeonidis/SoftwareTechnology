package main


import Administrator
import FakeDatabase
import Farmer
import api.apiRegionForecast
import api.apiRegionNow
import kotlinx.coroutines.runBlocking


const val adminMenu = "Select one of the following actions:\n" +
        "1. Logout\n" +
        "2. Delete User\n" +
        "3. View Users\n" +
        "4. Register New User"

fun app(user: Administrator) {
    var consoleInputString: String?
    while (true) {
        println(adminMenu)
        consoleInputString = readLine()?.trim() ?: ""
        when (consoleInputString) {
            "1" -> {
                return
            }

            "2" -> {
                println("Type the username of the user you want to delete.")
                consoleInputString = readLine()?.trim() ?: ""
                user.deleteUser(consoleInputString)
            }

            "3" -> {
                user.viewUsers()
            }

            "4" -> {
                user.registerUser()
            }
        }
    }
}

const val farmerMenu = "Select one of the following actions:\n" +
        "1. Logout\n" +
        "2. Delete Account\n" +
        "3. Weather now\n" +
        "4. 3-Day Forecast"

fun app(user: Farmer) {
    var consoleInputString: String?
    while (true) {
        println(farmerMenu)
        consoleInputString = readLine()?.trim() ?: ""
        when (consoleInputString) {
            "1" -> {
                return
            }

            "2" -> {
                FakeDatabase.users.remove(user)
                println("🗑️ Your account has been deleted.")
                return
            }

            "3" -> {
                weatherNowRegion()
            }

            "4" -> {
                forecastRegion()
            }
        }
    }
}

fun weatherNowRegion() {
    print("Enter region: ")
    val region = readLine()?.trim() ?: ""
    runBlocking {
        val response = apiRegionNow(region)
        if (response != null) {
            println()
            println("---- Weather now ----")
            println()
            println("\n📍 ${response.location.name}, ${response.location.region}, ${response.location.country}")
            println("🌡️ ${response.current.temp_c} °C / ${response.current.temp_f} °F")
            println("📝 ${response.current.condition.text}")
            println()
        } else {
            println("⚠️ Could not fetch weather data for '$region'.")
        }
    }
}

fun forecastRegion() {
    print("Enter region: ")
    val region = readLine()?.trim() ?: ""
    runBlocking {
        val response = apiRegionForecast(region)
        println()
        println("---- Forecast ----")
        println()
        response?.forecast?.forecastday?.forEach {
            println("📅 ${it.date}")
            println("🌡️ Max: ${it.day.maxtemp_c} °C, Min: ${it.day.mintemp_c} °C")
            println("🌤️ ${it.day.condition.text}")
            println()
        }
    }
}
