abstract class User (
    open val username: String,
    open val password: String,
    open val name: String,
    open val lastName: String,
    open val phoneNumber: String,
    open val email: String,
    open val address: String,
)