package api

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

const val apiKey = "637ecf4d26404bfd95f101215252805"

val client = HttpClient(CIO) {
    install(ContentNegotiation) {
        json(Json {
            ignoreUnknownKeys = true
        })
    }
}

// region Now

@Serializable
data class WeatherResponse(
    val location: Location,
    val current: Current
)

@Serializable
data class Location(val name: String, val region: String, val country: String)

@Serializable
data class Current(
    val temp_c: Double,
    val temp_f: Double,
    val condition: Condition,
    val is_day: Int,
    val humidity: Int
)

@Serializable
data class Condition(val text: String, val icon: String)

suspend fun apiRegionNow(city: String): WeatherResponse? {
    return try {
        val resp: WeatherResponse = client.get("https://api.weatherapi.com/v1/current.json") {
            parameter("key", apiKey)
            parameter("q", city)
        }.body()

        resp
    } catch (e: Exception) {
        null
    }
}

// endregion

// region Forecast

@Serializable
data class ForecastResponse(
    val location: Location,
    val forecast: Forecast
)

@Serializable
data class Forecast(
    val forecastday: List<ForecastDay>
)

@Serializable
data class ForecastDay(
    val date: String,
    val day: Day
)

@Serializable
data class Day(
    val maxtemp_c: Double,
    val mintemp_c: Double,
    val condition: Condition
)

suspend fun apiRegionForecast(city: String): ForecastResponse? {
    return try {
        client.get("https://api.weatherapi.com/v1/forecast.json") {
            parameter("key", apiKey)
            parameter("q", city)
            parameter("days", 3)
        }.body()
    } catch (e: Exception) {
        println("⚠️ Forecast request failed: ${e.localizedMessage}")
        null
    }
}

// endregion
