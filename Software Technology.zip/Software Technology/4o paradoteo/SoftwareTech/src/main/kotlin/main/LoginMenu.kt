package main

import Authentication
import User

fun loginMenu(): User? {
    print("Enter username: ")
    val username = readLine()?.trim() ?: ""

    print("Enter password: ")
    val password = readLine()?.trim() ?: ""

    val userOrNull = Authentication.login(username, password)
    if (userOrNull == null) {
        println("User authentication failed!")
    } else {
        println("Welcome back ${userOrNull.username}")
    }
    return userOrNull
}
