class Administrator(
    override val username: String,
    override val password: String,
    override val name: String,
    override val lastName: String,
    override val phoneNumber: String,
    override val email: String,
    override val address: String,
) : User(
    username = username,
    password = password,
    name = name,
    lastName = lastName,
    phoneNumber = phoneNumber,
    email = email,
    address = address
) {

    fun registerUser() {
        println("Registering new user")
        println()
        print("Type username: ")
        val username = readLine()?.trim() ?: ""
        println()
        print("Type password: ")
        val password = readLine()?.trim() ?: ""

        println()
        print("Type name: ")
        val name = readLine()?.trim() ?: ""

        println()
        print("Type lastname: ")
        val lastName = readLine()?.trim() ?: ""

        println()
        print("Type phone number: ")
        val phoneNumber = readLine()?.trim() ?: ""

        println()
        print("Type email: ")
        val email = readLine()?.trim() ?: ""

        println()
        print("Type address: ")
        val address = readLine()?.trim() ?: ""

        if (FakeDatabase.users.none { it.username == username }) {
            FakeDatabase.users.add(
                Farmer(
                    username = username,
                    password = password,
                    name = name,
                    lastName = lastName,
                    phoneNumber = phoneNumber,
                    email = email,
                    address = address
                )
            )
            println("User : $username has been created!")
        } else {
            println("User with this username already exists! Cancelling registration!")
        }
    }

    fun deleteUser(username: String) {
        val foundUser = FakeDatabase.users.firstOrNull { user ->
            user.username == username
        }
        if (foundUser == null) {
            println("Given username not found!")
        } else {
            println("User with username ${foundUser.username}")
            println("Are you sure you want to delete him? (Y/n)")
            var consoleInputString = readLine()?.trim() ?: ""
            while (consoleInputString != "n" && consoleInputString != "N" && consoleInputString != "Y") {
                consoleInputString = readLine()?.trim() ?: ""
            }
            if (consoleInputString == "Y") {
                FakeDatabase.users.remove(foundUser)
                println("User ${foundUser.username} deleted!")
            }
        }
    }

    fun viewUsers() {
        FakeDatabase.users.forEach { user ->
            user.printFormat()
        }
    }
}

fun User.printFormat() {
    println("========================================")
    println("           USER INFORMATION")
    println("========================================")
    println("First Name  : ${this.name}")
    println("Last Name   : ${this.lastName}")
    println("Username    : ${this.username}")
    println("Phone       : ${this.phoneNumber}")
    println("Email       : ${this.email}")
    println("Address     : ${this.address}")
    println("========================================")
}