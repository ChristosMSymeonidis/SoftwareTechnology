object Authentication {
    fun login(username: String, password: String): User? {
        val userChecked = FakeDatabase.users.firstOrNull { user ->
            user.username == username && user.password == password
        }
        return userChecked
    }
}