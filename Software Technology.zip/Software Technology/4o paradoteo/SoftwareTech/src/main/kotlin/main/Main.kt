package main

import Administrator
import Farmer

const val mainMenu = "Select one of the following actions:\n" +
        "1. Login\n" +
        "2. Cancel"

fun main() {
    var consoleInputString: String?
    while (true) {
        println(mainMenu)
        consoleInputString = readLine()?.trim() ?: ""
        if (consoleInputString == "1") {
            val user = loginMenu()
            if (user != null) {
                when(user) {
                    is Administrator -> app(user)
                    is Farmer -> app(user)
                }
            }
        } else if (consoleInputString == "2") {
            return
        }
    }
}

