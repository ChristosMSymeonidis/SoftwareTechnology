class MailServerSystem {
    fun informAction(user: User, message: String) {
        println("Sending email to ${user.email}: $message")
    }
}