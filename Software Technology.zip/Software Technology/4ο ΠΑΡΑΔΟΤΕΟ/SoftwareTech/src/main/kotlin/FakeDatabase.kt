object FakeDatabase {
    val users = mutableListOf<User>(
        Farmer(
            username = "farmer1",
            password = "pass1",
            name = "John",
            lastName = "Doe",
            phoneNumber = "1234567890",
            email = "john.doe@farmmail.com",
            address = "123 Field Lane"
        ),
        Farmer(
            username = "farmer2",
            password = "pass2",
            name = "Alice",
            lastName = "Green",
            phoneNumber = "0987654321",
            email = "alice.green@farmmail.com",
            address = "789 Countryside Road"
        ),
        Administrator(
            username = "admin01",
            password = "pass",
            name = "Bob",
            lastName = "Adminson",
            phoneNumber = "1112223333",
            email = "admin@agroclima.com",
            address = "1 Admin HQ"
        )
    )
}